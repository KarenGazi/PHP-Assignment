<!doctype html>
<html>
<head>

</head>
<body>
	<?php
      $name=$_GET['name'];
      $email=$_GET['email'];
      echo "your first name is $name your surname is $email";

      if($_POST['name']=='karen' && $_POST['email']=='gazikaren@gmail.com'){

        ?>
        <a href="myform.php?name=<?php echo $_POST[name]?>">
          Go To Profile Page
        </a>
        <?php

      } 
      else{
      	?>
      	<a href="myform.php">Log in failure go to home</a>
      	<?php
      }

	?>
</body>
</html>