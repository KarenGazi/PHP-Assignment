<html>
<body>

  <?php
  $name=$_POST['name'];
  $email=$_POST['email'];
  $idnumber=$_POST['idnumber'];
  $dob=$_POST['dob'];
  $organisation=$_POST['oragnisation'];
  $address=$_POST['address'];
  $phonenumber=$_POST['phonenumber'];
  $cover=$_POST['cover'];
  $TypesofInsurance=$_POST['TypesofInsurance'];

  
  
      

echo "name: $name<br>";
echo "email: $email<br>";


 echo "ID number $idnumber <br>";
 echo "date of birth $dob<br>";


 echo "Business or Occupation: $organisation<br>";
  echo "Your address is:= $address<br>";


echo "Your phone number is: $phonenumber<br>";
 echo "Restricted Cover: $cover <br>"; 


 echo "Type of insurance:$TypesofInsurance <br>";

?>
</body>
</html>