<!...Doctype html>
<html>
	  <head>
		  <title>Forms</title>
		    <!-- Bootstrap -->
      <link href="css/bootstrap.min.css" rel="stylesheet">
	       <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
        <script src="../js/jquery.min.js"></script>
          <!-- Include all compiled plugins (below), or include individual files as needed -->
        <script src="js/bootstrap.min.js"></script>

    <center>
         <header>
            <div id="img" class="header-div">
            <img src="logo.jpg" id="logo">

          </header>
    </center>
            </div>
	  </head>


	 <body>
    <?php

    ?>
        <center>
    
	          <div id="img" class="header-div">
              <img src="1.jpg" id="1">

              <ul class="nav nav-list">
              <li class="active"><a href="#"><i class="icon-home icon-white"></i> Home</a></li>
              <li><a href="#"><i class="icon-book"></i>Forms</a></li>
              <li><a href="#"><i class="i"></i>Contact Us</a></li>
              </ul>
        </center>

        <h3 class="well">Insurence Application Form</h3>
        <h3 class="well">Please use block letters<h3>

	       <form class="form-inline" role="form" action="processmyform.php" method="post" action="login_get.php" method="get">
              <div class="form-group">
                   <label for="email">Email address</label>
                   <input class="input-block-level" type="text" placeholder="rudo@gmail.com">
              </div>

               <div class="form-inline">
                   <label for="name">Name(in full)</label>
                  <input class="input-block-level" type="text" required>

               <div class="form-inline">
               <div class="form-inline">
                   <label for="idnumber">ID number</label>
                   <input type="idnumber" class="input-xxlarge" id="idnumber"  required>
                </div>

                <div>
                    <label for="dob">Date Of Birth</label>
                    <input type="date" required ></input>
                </div>

                 <div class="form-inline">
                   <label for="gender">Sex</label>
                  <input class="input-xxlarge" type="text" required>
      
                <div class="form-inline">
                      <label for="organisation">Business or Occupation</label>
                     <textarea class="input-block-level" rows="3"></textarea>
                </div>

                      <label for="address">Address</label>
                     <input class="input-block-level" type="text" required>
                </div>
   
                <div class="form-inline">

                    <label for="phonenumber">Phone Number</label>
                     <input type="text" id="phonenumber" maxlength="20" required placeholder="+263" tabindex="1"></input>
                </div>
   
                <div>
                    <br><h4 class ="well">Schedule For Persons To Be Insured</h4>
                </div>

              <section>
                  <article>
                            <p id="first-article-item" class="article-item"><h6>The insurance can be applied to:<br><br>i) a fixed scale of compansation for named persons insuring themselves and for employers who wish to insure named employees<br>i)compansation on chosen multiples of avarange monthly earnings for employers who wish named and unnamed employees<h6></p>
                  </article>
              </section>

              <div class="form-inline">
                     <label for="cover">Do You Require Resticted Cover?</label>
                     <input class="input-xxlarge"type="text" required>
              </div>
              <div class="form-inline"><label for="level">Type Of Insurance</label>
                  <select>
                        <optgroup label="TypesofInsurance"></optgroup>
                        <option value=""></option>
                        <option value="accident">Accident</option>
                        <option value="fire">Fire</option>
                        <option value="group">Group</option>
                        <option value="life">Life</option>
                        <option value="marine">Marine</option>
                        <option value="mutual">Mutual</option>
                        <option value="national">National</option>
                        <option value="participating">Participating</option>
                        <option value="permanent health">Permanet Health</option>
                        <option value="private health">Private Health</option>
                        <option value="public liability">Public Liability</option>
                        <option value="self insuarence">Self Insuarence</option>
                        <option value="social">Social</option>
                        <option value="term">Term</option>
            
                  </select>

                  <div class="checkbox">
                 
                      <input type="checkbox">
                     <button class="btn btn-small btn-success" type="button">Bronze</button>
                  
                  <div class="checkbox">
                      <input type="checkbox">   <button class="btn btn-small btn-info" type="button">Silver</button>

                  <div class="checkbox">
                      <input type="checkbox">   <button class="btn btn-small btn-warning" type="button">Gold</button>
    
                  <div class="checkbox">
                      <input type="checkbox">   <button class="btn btn-small btn-danger" type="button">Platinum</button>
                  </div>
                  </div>

                  <div><h5 class="well well-small">Make Payments Using Any Of The Following Means</h5></div>
                  <div class="checkbox">

                 <label>
                      <input type="checkbox">Visa
                 </label>

                 <div class="checkbox">
                    <label>
                       <input type="checkbox">Bank Transfer
                    </label>

                  <div class="checkbox">
                     <label>
                          <input type="checkbox">Telecash
                    </label>

                  <div class="checkbox">
                    <label>
                        <input type="checkbox">Ecocash
                   </label>

                  <div class="checkbox">
                     <label>
                        <input type="checkbox">Cash Deposit
                    </label>
                  </div>

                  <div>
                      <h4 class="well well-small">Beneficiaries</h4>
                  </div>

                 <div class="form-inline">
                      <label for="exampleInputFile">File input</label>
                      <input type="file" id="exampleInputFile">
                      <p class="help-block"></p>
                </div>

                <div class="checkbox">
                     <label>
                          <input type="checkbox">Please Tick if you have provided the correct information...(terms and conditions apply)
                    </label>

                <div><label for="cover">Signature.....................................</label></div>
                </div>

                      <button type="submit" class="btn btn-primary">Submit</button></button>
 
       </form>

   </body>
</html>